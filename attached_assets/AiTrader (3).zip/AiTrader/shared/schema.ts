import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const signals = pgTable("signals", {
  id: serial("id").primaryKey(),
  currencyPair: text("currency_pair").notNull(),
  direction: text("direction").notNull(),
  expirationTime: integer("expiration_time").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signals).pick({
  currencyPair: true,
  direction: true,
  expirationTime: true,
});

export const currencyPairs = [
  "EUR/USD",
  "GBP/USD",
  "USD/CAD",
  "USD/JPY",
  "AUD/USD",
  "USD/CHF",
  "NZD/USD",
  "USD/BRL",
] as const;

export const expirationTimes = [1, 2, 5] as const;

export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signals.$inferSelect;
export type CurrencyPair = typeof currencyPairs[number];
export type ExpirationTime = typeof expirationTimes[number];