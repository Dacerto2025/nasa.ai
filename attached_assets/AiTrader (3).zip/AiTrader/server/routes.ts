
import type { Express } from "express";
import { createServer } from "http";
import { formatInTimeZone } from "date-fns-tz";
import { addMinutes } from "date-fns";
import type { CurrencyPair, ExpirationTime } from "../shared/schema";

let useOneMinute = true;

export async function registerRoutes(app: Express) {
  app.use((err: any, _req: any, res: any, next: any) => {
    console.error(err);
    res.status(500).json({
      error: "Ocorreu um erro no servidor. Por favor, tente novamente."
    });
    next(err);
  });

  app.post("/api/signals", async (req, res) => {
    const currencyPair = req.body.currencyPair as CurrencyPair;
    const expirationTime = req.body.expirationTime as ExpirationTime;

    if (!currencyPair || !expirationTime) {
      return res.status(400).json({ 
        error: "Por favor, selecione um par de moedas e tempo de expiração",
        fields: {
          currencyPair: !currencyPair ? "Selecione um par de moedas" : null,
          expirationTime: !expirationTime ? "Selecione o tempo de expiração" : null
        }
      });
    }

    try {

    // Garante um tempo mínimo para entrada
    const now = new Date();
    now.setSeconds(now.getSeconds() + 30); // Adiciona 30 segundos para dar tempo de entrada
    
    // Alterna entre 1 e 2 minutos
    const futureMinutes = useOneMinute ? 1 : 2;
    useOneMinute = !useOneMinute;
    
    // Gera direção baseada em timestamp para mais aleatoriedade
    const direction = (now.getTime() % 2) === 0 ? "UP" : "DOWN";
    
    const signalTime = addMinutes(now, futureMinutes);
    const formattedTime = formatInTimeZone(signalTime, 'America/Sao_Paulo', 'HH:mm');

    res.json({
      direction,
      signalTime: formattedTime,
      currencyPair,
      expirationTime
    });
    } catch (error) {
      console.error("Erro ao gerar sinal:", error);
      res.status(500).json({
        error: "Não foi possível gerar o sinal. Por favor, tente novamente."
      });
    }
  });

  return createServer(app);
}
