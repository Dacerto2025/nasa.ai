import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { type CurrencyPair, currencyPairs } from "@shared/schema";

const flagEmojis: Record<string, string> = {
  EUR: "🇪🇺",
  USD: "🇺🇸",
  GBP: "🇬🇧",
  CAD: "🇨🇦",
  JPY: "🇯🇵",
  AUD: "🇦🇺",
  CHF: "🇨🇭",
  NZD: "🇳🇿",
  BRL: "🇧🇷",
};

interface Props {
  value: CurrencyPair | null;
  onChange: (pair: CurrencyPair) => void;
}

export default function CurrencyPairSelector({ value, onChange }: Props) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">1️⃣ Escolha o par de moedas</h2>
      <Select value={value || undefined} onValueChange={(val) => onChange(val as CurrencyPair)}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Selecione um par de moedas" />
        </SelectTrigger>
        <SelectContent>
          {currencyPairs.map((pair) => {
            const [base, quote] = pair.split("/");
            return (
              <SelectItem key={pair} value={pair}>
                <span className="flex items-center gap-2">
                  <span>{flagEmojis[base]}</span>
                  <span>{base}</span>
                  <span>/</span>
                  <span>{flagEmojis[quote]}</span>
                  <span>{quote}</span>
                </span>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
    </div>
  );
}