
import { motion } from "framer-motion";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface Props {
  disabled: boolean;
  onGenerate: () => Promise<void>;
}

export default function GenerateButton({ disabled, onGenerate }: Props) {
  const [isGenerating, setIsGenerating] = useState(false);

  return (
    <div className="flex justify-center">
      <motion.div
        animate={{
          scale: isGenerating ? [1, 1.05, 1] : 1,
          boxShadow: isGenerating ? "0 0 25px rgba(11, 61, 145, 0.5)" : "none"
        }}
        transition={{ duration: 0.5, repeat: isGenerating ? Infinity : 0 }}
      >
        <Button
          size="lg"
          disabled={disabled || isGenerating}
          onClick={async () => {
            try {
              setIsGenerating(true);
              await onGenerate();
            } catch (error) {
              console.error(error);
            } finally {
              setIsGenerating(false);
            }
          }}
          className={`
            relative px-8 py-6 text-lg font-bold 
            bg-gradient-to-r from-[#0B3D91] to-[#FC3D21] 
            hover:opacity-90 transition-all duration-300
            ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105'}
          `}
        >
          {isGenerating ? "⏳ Gerando..." : "🚀 GERAR SINAL"}
        </Button>
      </motion.div>
    </div>
  );
}
