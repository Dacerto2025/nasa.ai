import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { expirationTimes, type ExpirationTime } from "@shared/schema";

interface Props {
  value: ExpirationTime | null;
  onChange: (time: ExpirationTime) => void;
}

export default function ExpirationSelector({ value, onChange }: Props) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">2️⃣ Escolha o tempo de expiração</h2>
      <div className="grid grid-cols-3 gap-4">
        {expirationTimes.map((time) => {
          const isSelected = value === time;
          
          return (
            <motion.div
              key={time}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card
                className={`
                  cursor-pointer p-4 text-center transition-all
                  ${isSelected ? 'border-2 border-primary shadow-[0_0_10px_rgba(var(--primary),0.3)]' : ''}
                `}
                onClick={() => onChange(time)}
              >
                <p className="text-xl font-bold">{time}</p>
                <p className="text-sm text-muted-foreground">
                  {time === 1 ? 'minuto' : 'minutos'}
                </p>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
