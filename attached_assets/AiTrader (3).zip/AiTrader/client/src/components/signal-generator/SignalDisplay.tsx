
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";

interface Props {
  signal: {
    direction: "UP" | "DOWN";
    signalTime: string;
    currencyPair: string;
    expirationTime: number;
  };
}

export default function SignalDisplay({ signal }: Props) {
  const isUp = signal.direction === "UP";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center"
    >
      <Card className={`
        p-6 border-4 shadow-lg transform hover:scale-105 transition-transform
        ${isUp ? 'border-green-500 bg-green-500/10' : 'border-red-500 bg-red-500/10'}
      `}>
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring" }}
        >
          <p className="text-3xl font-bold mb-4">
            {isUp ? '🚀 COMPRA' : '📉 VENDA'}
          </p>
          <p className="text-2xl font-bold mb-2">
            {signal.currencyPair}
          </p>
          <p className="text-xl font-bold">
            ⏰ Entrada: {signal.signalTime}
          </p>
          <p className="text-lg mt-2 opacity-90">
            ⌛ Expiração: {signal.expirationTime} {signal.expirationTime === 1 ? 'minuto' : 'minutos'}
          </p>
        </motion.div>
      </Card>
    </motion.div>
  );
}
