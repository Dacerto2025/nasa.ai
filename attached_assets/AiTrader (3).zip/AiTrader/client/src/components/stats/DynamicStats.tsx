import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';

export default function DynamicStats() {
  const [onlineUsers, setOnlineUsers] = useState(1250);
  
  // Increment online users every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setOnlineUsers(prev => prev + Math.floor(Math.random() * 5) + 1);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="p-4 bg-[#0B3D91]/20 border-[#0B3D91]">
          <p className="text-sm text-gray-400">Taxa de assertividade</p>
          <p className="text-2xl font-bold text-green-500">99.98%</p>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="p-4 bg-[#0B3D91]/20 border-[#0B3D91]">
          <p className="text-sm text-gray-400">Usuários online</p>
          <p className="text-2xl font-bold text-blue-500">{onlineUsers}</p>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="p-4 bg-[#0B3D91]/20 border-[#0B3D91]">
          <p className="text-sm text-gray-400">Lucro semanal</p>
          <p className="text-2xl font-bold text-green-500">R$ 350.000+</p>
        </Card>
      </motion.div>
    </div>
  );
}
