import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { MessageCircle } from 'lucide-react';

const testimonials = [
  {
    name: "Lucas A.",
    message: "Comecei com R$ 500 e já estou com R$ 3.250 em dois dias! NASA I.A é surreal!"
  },
  {
    name: "Mariana S.",
    message: "Nunca acertei tanto operando! Fiz R$ 12.500 essa semana, só gratidão!"
  },
  {
    name: "Anderson P.",
    message: "Primeiro mês usando e já passei dos R$ 50K! Simplesmente a melhor IA do mercado!"
  },
  {
    name: "Rafael G.",
    message: "Testei várias estratégias antes, mas nada chega perto da NASA I.A. Já saquei R$ 8.900!"
  },
  {
    name: "Camila F.",
    message: "Com apenas R$ 100, transformei em R$ 1.700 em poucas horas. Não tem erro!"
  },
  {
    name: "Thiago M.",
    message: "Comecei desacreditado, mas agora estou fechando semanas com R$ 15.000 de lucro!"
  },
  {
    name: "Fernanda P.",
    message: "A melhor decisão que tomei foi começar a usar a NASA I.A! Meu lucro mensal explodiu!"
  },
  {
    name: "Henrique D.",
    message: "Já testei outras plataformas, mas essa é incomparável. Precisa ver para crer!"
  },
  {
    name: "Vanessa C.",
    message: "Meu primeiro saque foi de R$ 20.000. NASA I.A mudou meu jogo completamente!"
  }
];

export default function LiveTestimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentTestimonials, setCurrentTestimonials] = useState(testimonials.slice(0, 3));

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
      setCurrentTestimonials(prevTestimonials => {
        const nextIndex = (currentIndex + 3) % testimonials.length;
        return [
          testimonials[currentIndex],
          testimonials[(currentIndex + 1) % testimonials.length],
          testimonials[(currentIndex + 2) % testimonials.length]
        ];
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [currentIndex]);

  return (
    <div className="space-y-4 mb-8">
      <div className="flex items-center gap-2 mb-4">
        <MessageCircle className="w-5 h-5 text-[#FC3D21]" />
        <h2 className="text-xl font-semibold">Feedbacks em tempo real</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {currentTestimonials.map((testimonial, index) => (
            <motion.div
              key={`${testimonial.name}-${index}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-4 bg-[#0B3D91]/20 border-[#0B3D91] h-full">
                <div className="flex flex-col h-full">
                  <p className="text-sm text-gray-400 mb-2">{testimonial.name}</p>
                  <p className="text-white flex-grow">{testimonial.message}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
