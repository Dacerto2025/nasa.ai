import { motion } from "framer-motion";
import CurrencyPairSelector from "@/components/signal-generator/CurrencyPairSelector";
import ExpirationSelector from "@/components/signal-generator/ExpirationSelector";
import SignalDisplay from "@/components/signal-generator/SignalDisplay";
import GenerateButton from "@/components/signal-generator/GenerateButton";
import DynamicStats from "@/components/stats/DynamicStats";
import LiveTestimonials from "@/components/testimonials/LiveTestimonials";
import { useState } from "react";
import type { CurrencyPair, ExpirationTime } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  const [selectedPair, setSelectedPair] = useState<CurrencyPair | null>(null);
  const [selectedExpiration, setSelectedExpiration] = useState<ExpirationTime | null>(null);
  const [signal, setSignal] = useState<any>(null);

  return (
    <div className="min-h-screen bg-[#020B1C] text-white p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-6xl mx-auto space-y-8"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-[#0B3D91] via-white to-[#FC3D21] bg-clip-text text-transparent">
            NASA I.A TRADER 🚀
          </h1>
          <p className="text-xl text-gray-400">
            O GERADOR DE SINAIS MAIS PODEROSO DO MERCADO!
          </p>
        </div>

        <DynamicStats />

        <Card className="border-2 border-[#0B3D91]/20 bg-[#0B3D91]/10">
          <CardContent className="p-6 space-y-6">
            <CurrencyPairSelector
              value={selectedPair}
              onChange={setSelectedPair}
            />

            <ExpirationSelector
              value={selectedExpiration}
              onChange={setSelectedExpiration}
            />

            <GenerateButton
              disabled={!selectedPair || !selectedExpiration}
              onGenerate={async () => {
                try {
                  if (!selectedPair || !selectedExpiration) return;
                  const response = await fetch("/api/signals", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      currencyPair: selectedPair,
                      expirationTime: selectedExpiration
                    })
                  });
                  
                  if (!response.ok) {
                    throw new Error('Falha ao gerar sinal');
                  }
                  
                  const data = await response.json();
                  setSignal(data);
                } catch (error) {
                  console.error('Erro:', error);
                  alert('Falha ao gerar sinal. Tente novamente.');
                }
              }}
            />

            {signal && <SignalDisplay signal={signal} />}

            <a
              href="https://exnova.com/lp/start-trading/?aff=751488&aff_model=revenue&afftrack="
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full"
            >
              <motion.button
                whileHover={{ scale: 1.02 }}
                className="w-full py-4 px-6 bg-[#FC3D21] hover:bg-[#FC3D21]/90 text-white rounded-lg font-bold text-lg"
              >
                Acesse a Corretora da NASA
              </motion.button>
            </a>
            <div className="space-y-2 text-center">
              <p className="text-sm text-gray-400">
                Aqui os sinais funcionam!
              </p>
              <p className="text-lg font-semibold bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-500 bg-clip-text text-transparent animate-pulse">
                No seu primeiro depósito, use o código NASA300 e ganhe 3x mais de presente!
              </p>
            </div>
          </CardContent>
        </Card>

        <LiveTestimonials />
      </motion.div>
    </div>
  );
}