import { type CurrencyPair, type ExpirationTime } from "@shared/schema";

export interface TradingSignal {
  direction: "UP" | "DOWN";
  signalTime: string;
  currencyPair: CurrencyPair;
  expirationTime: ExpirationTime;
}

/**
 * Validates whether a currency pair is valid for trading
 */
export function isValidCurrencyPair(pair: string): pair is CurrencyPair {
  const [base, quote] = pair.split("/");
  return !!(base && quote && base.length === 3 && quote.length === 3);
}

/**
 * Gets the flags for a currency pair
 */
export function getCurrencyPairFlags(pair: CurrencyPair): [string, string] {
  const flagEmojis: Record<string, string> = {
    EUR: "🇪🇺",
    USD: "🇺🇸", 
    GBP: "🇬🇧",
    CAD: "🇨🇦",
    JPY: "🇯🇵",
    AUD: "🇦🇺",
    CHF: "🇨🇭",
    NZD: "🇳🇿",
    BRL: "🇧🇷"
  };

  const [base, quote] = pair.split("/");
  return [flagEmojis[base], flagEmojis[quote]];
}

/**
 * Formats an expiration time with proper pluralization
 */
export function formatExpirationTime(time: ExpirationTime): string {
  return `${time} ${time === 1 ? 'minuto' : 'minutos'}`;
}

/**
 * Get style variants for signal direction
 */
export function getSignalStyles(direction: "UP" | "DOWN") {
  return {
    borderColor: direction === "UP" ? "border-green-500" : "border-red-500",
    textColor: direction === "UP" ? "text-green-500" : "text-red-500",
    icon: direction === "UP" ? "🔺" : "🔻"
  };
}

/**
 * Validates if a signal can be generated based on pair and expiration
 */
export function canGenerateSignal(
  pair: CurrencyPair | null,
  expiration: ExpirationTime | null
): boolean {
  return !!pair && !!expiration;
}

/**
 * Helper to adjust current time to Brasília timezone
 */
export function getBrasiliaTime(): string {
  const date = new Date();
  // Adjust time by 1-2 minutes ahead as specified
  const adjustMinutes = Math.random() > 0.5 ? 1 : 2;
  date.setMinutes(date.getMinutes() + adjustMinutes);

  return date.toLocaleTimeString('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}

/**
 * Generates trading signal with random direction
 */
export async function generateSignal(
  currencyPair: CurrencyPair,
  expirationTime: ExpirationTime
): Promise<TradingSignal> {
  const direction = Math.random() > 0.5 ? "UP" : "DOWN";
  const signalTime = getBrasiliaTime();

  return {
    direction,
    signalTime,
    currencyPair,
    expirationTime
  };
}